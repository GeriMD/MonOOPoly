#pragma once

enum class PropertyColour {
	BROWN, LIGHT_BLUE, PINK, ORANGE, RED, YELLOW, GREEN, DARK_BLUE, DEFAULT_COLOR
};
