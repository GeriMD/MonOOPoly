#pragma once
#include "Command.h"

class SaveGameCommand : public Command
{
public:
	SaveGameCommand() = default;
	virtual void executeCommand() override;
};

