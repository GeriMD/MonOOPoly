#pragma once

namespace Constants {
	const char CARDS_FILE_NAME[] = "Cards.txt";
	const char FIELDS_FILE_NAME[] = "Fields1.txt";
}
