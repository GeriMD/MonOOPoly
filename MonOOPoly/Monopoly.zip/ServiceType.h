#pragma once

enum class ServiceType {
	WATER_SERVICE, ELECTRICITY_SERVICE, DEFAULT
};