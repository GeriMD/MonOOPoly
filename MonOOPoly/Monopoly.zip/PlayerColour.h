#pragma once

enum class PlayerColour {
	RED, BLUE, GREEN, YELLOW, WHITE, PURPLE, DEFAULT
};
