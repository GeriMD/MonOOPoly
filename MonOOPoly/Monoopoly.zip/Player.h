#pragma once
#include "MyString.h"
#pragma warning(disable:4996)

class Player
{
private:
	MyString name;

	int playerIndex;
	int currentPlayerPositionIndex;
	int playersMoney;

	bool skipTurn = false;
	//TODO: Add properties

public:
	Player();
	Player(MyString name, int playerIndex); //TODO: Maybe add balance?

	int getPlayersIndex() const;
	int getCurrentPosition() const;
	int getPlayersMoney() const;
	
	//TODO: add more functions

};

