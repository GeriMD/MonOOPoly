#include "Player.h"

Player::Player()
{
}

Player::Player(MyString name, int playerIndex)
{
    this->name = name;
    this->playerIndex = playerIndex;
}

int Player::getPlayersIndex() const
{
    return playerIndex;
}

int Player::getCurrentPosition() const
{
    return currentPlayerPositionIndex;
}

int Player::getPlayersMoney() const
{
    return playersMoney;
}
